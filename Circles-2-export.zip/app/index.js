import clock from "clock";
import document from "document";
import * as util from "../common/utils";
import { HeartRateSensor } from "heart-rate";
import { display } from "display";
import * as messaging from "messaging";

import * as kpay from './kpay/release/kpay.js';
import * as kpay_common from '../common/kpay/kpay_common.js';
import './kpay/release/kpay_filetransfer.js';
import './kpay/release/kpay_dialogs.js';
import './kpay/release/kpay_time_trial.js';
// import './kpay/release/kpay_msg_validation.js';	
kpay.initialize();

const Hours = document.getElementById("Hours");
const Mins = document.getElementById("Minutes");
const Day = document.getElementById("Day");
const Date = document.getElementById("Date");
const Circle1Prog = document.getElementById("Circle1Prog");
const Circle2Prog = document.getElementById("Circle2Prog");
const Circle3Prog = document.getElementById("Circle3Prog");
const Circle4Prog = document.getElementById("Circle4Prog");
const Circle5Prog = document.getElementById("Circle5Prog");
const Circle6Prog = document.getElementById("Circle6Prog");
const Circle1Text = document.getElementById("Circle1Text");
const Circle2Text = document.getElementById("Circle2Text");
const Circle3Text = document.getElementById("Circle3Text");
const Circle4Text = document.getElementById("Circle4Text");
const Circle5Text = document.getElementById("Circle5Text");
const Circle6Text = document.getElementById("Circle6Text");
const Circle1Label = document.getElementById("Circle1Label");
const Circle2Label = document.getElementById("Circle2Label");
const Circle3Label = document.getElementById("Circle3Label");
const Circle4Label = document.getElementById("Circle4Label");
const Circle5Label = document.getElementById("Circle5Label");
const Circle6Label = document.getElementById("Circle6Label");

util.loadSettings();

if (HeartRateSensor) {
    const hrm = new HeartRateSensor();
    hrm.addEventListener("reading", () => {});
    display.addEventListener("change", () => {
    display.on ? hrm.start() : hrm.stop();});
    hrm.onreading = function() {
      if(util.getCircleData(1)=="HR") {
        Circle1Text.text = `${hrm.heartRate}`;
        Circle1Label.text=util.getLabel(1);
        let Circle1Fill = parseInt(Circle1Text.text)/util.getCircleBoundary(1)*360;
        if(Circle1Fill>360) {Circle1Prog.sweepAngle = 360;}
        else {Circle1Prog.sweepAngle = Circle1Fill;}
      }
      if(util.getCircleData(2)=="HR") {
        Circle2Text.text = `${hrm.heartRate}`; 
        Circle2Label.text=util.getLabel(2);
        let Circle2Fill = parseInt(Circle2Text.text)/util.getCircleBoundary(2)*360;
        if(Circle2Fill>360) {Circle2Prog.sweepAngle = 360;}
        else {Circle2Prog.sweepAngle = Circle2Fill;}
      }
      if(util.getCircleData(3)=="HR") {
        Circle3Text.text = `${hrm.heartRate}`; 
        Circle3Label.text=util.getLabel(3);
        let Circle3Fill = parseInt(Circle3Text.text)/util.getCircleBoundary(3)*360;
        if(Circle3Fill>360) {Circle3Prog.sweepAngle = 360;}
        else {Circle3Prog.sweepAngle = Circle3Fill;}
      }
      if(util.getCircleData(4)=="HR") {
        Circle4Text.text = `${hrm.heartRate}`; 
        Circle4Label.text=util.getLabel(4);
        let Circle4Fill = parseInt(Circle4Text.text)/util.getCircleBoundary(4)*360;
        if(Circle4Fill>360) {Circle4Prog.sweepAngle = 360;}
        else {Circle4Prog.sweepAngle = Circle4Fill;}
      }
      if(util.getCircleData(5)=="HR") {
        Circle5Text.text = `${hrm.heartRate}`; 
        Circle5Label.text=util.getLabel(5);
        let Circle5Fill = parseInt(Circle5Text.text)/util.getCircleBoundary(5)*360;
        if(Circle5Fill>360) {Circle5Prog.sweepAngle = 360;}
        else {Circle5Prog.sweepAngle = Circle5Fill;}
      }
      if(util.getCircleData(6)=="HR") {
        Circle6Text.text = `${hrm.heartRate}`; 
        Circle6Label.text=util.getLabel(6);
        let Circle6Fill = parseInt(Circle6Text.text)/util.getCircleBoundary(6)*360;
        if(Circle6Fill>360) {Circle6Prog.sweepAngle = 360;}
        else {Circle6Prog.sweepAngle = Circle6Fill;}
      }
    }
    hrm.start();
}

clock.granularity = "seconds";
clock.ontick = (evt) => {
  let today = evt.date;
  let hours = today.getHours();
  if (util.timeFormat == "12") {
    Hours.text = hours % 12 || 12;
  } 
  else {
    Hours.text = util.zeroPad(hours);
  }
  Mins.text = util.zeroPad(today.getMinutes());
  Day.text = util.getDay(today.getDay());
  Date.text = util.getDate(today.getDate(),today.getMonth()+1);
  
  messaging.peerSocket.onmessage = function(evt) {
    if(evt.data.key=="Circle1Element") {
      util.setElement(1,evt.data.value.selected);
    }
    if(evt.data.key=="Circle2Element") {
      util.setElement(2,evt.data.value.selected);
    }
    if(evt.data.key=="Circle3Element") {
      util.setElement(3,evt.data.value.selected);
    }
    if(evt.data.key=="Circle4Element") {
      util.setElement(4,evt.data.value.selected);
    }
    if(evt.data.key=="Circle5Element") {
      util.setElement(5,evt.data.value.selected);
    }
    if(evt.data.key=="Circle6Element") {
      util.setElement(6,evt.data.value.selected);
    }
    if(evt.data.key=="Circle1Colour") {
      Circle1Prog.style.fill = evt.data.value;
    }
    if(evt.data.key=="Circle2Colour") {
      Circle2Prog.style.fill = evt.data.value;
    }
    if(evt.data.key=="Circle3Colour") {
      Circle3Prog.style.fill = evt.data.value;
    }
    if(evt.data.key=="Circle4Colour") {
      Circle4Prog.style.fill = evt.data.value;
    }
    if(evt.data.key=="Circle5Colour") {
      Circle5Prog.style.fill = evt.data.value;
    }
    if(evt.data.key=="Circle6Colour") {
      Circle6Prog.style.fill = evt.data.value;
    }
    if(evt.data.key=="DateFormat") {
      util.toggleDateFormat();
    }
    if(evt.data.key=="TimeFormat") {
      util.toggleTimeFormat();
    }
    util.saveSettings();
  }
  
  
  if(util.getCircleData(1)!="HR"&&util.getCircleData(1)!="Sec") {
    Circle1Text.text = util.getCircleData(1);
    Circle1Label.text=util.getLabel(1);
    let Circle1Fill = util.getCircleData(1)/util.getCircleBoundary(1)*360;
    if(Circle1Fill>360) {Circle1Prog.sweepAngle = 360;}
    else {Circle1Prog.sweepAngle = Circle1Fill;}
  }
  if(util.getCircleData(2)!="HR"&&util.getCircleData(2)!="Sec") {
    Circle2Text.text = util.getCircleData(2);
    Circle2Label.text=util.getLabel(2);
    let Circle2Fill = util.getCircleData(2)/util.getCircleBoundary(2)*360;
    if(Circle2Fill>360) {Circle2Prog.sweepAngle = 360;}
    else {Circle2Prog.sweepAngle = Circle2Fill;}
  }
  if(util.getCircleData(3)!="HR"&&util.getCircleData(3)!="Sec") {
    Circle3Text.text = util.getCircleData(3);
    Circle3Label.text=util.getLabel(3);
    let Circle3Fill = util.getCircleData(3)/util.getCircleBoundary(3)*360;
    if(Circle3Fill>360) {Circle3Prog.sweepAngle = 360;}
    else {Circle3Prog.sweepAngle = Circle3Fill;}
  }
  if(util.getCircleData(4)!="HR"&&util.getCircleData(4)!="Sec") {
    Circle4Text.text = util.getCircleData(4);
    Circle4Label.text=util.getLabel(4);
    let Circle4Fill = util.getCircleData(4)/util.getCircleBoundary(4)*360;
    if(Circle4Fill>360) {Circle4Prog.sweepAngle = 360;}
    else {Circle4Prog.sweepAngle = Circle4Fill;}
  }
  if(util.getCircleData(5)!="HR"&&util.getCircleData(5)!="Sec") {
    Circle5Text.text = util.getCircleData(5);
    Circle5Label.text=util.getLabel(5);
    let Circle5Fill = util.getCircleData(5)/util.getCircleBoundary(5)*360;
    if(Circle5Fill>360) {Circle5Prog.sweepAngle = 360;}
    else {Circle5Prog.sweepAngle = Circle5Fill;}
  }
  if(util.getCircleData(6)!="HR"&&util.getCircleData(6)!="Sec") {
    Circle6Text.text = util.getCircleData(6);
    Circle6Label.text=util.getLabel(6);
    let Circle6Fill = util.getCircleData(6)/util.getCircleBoundary(6)*360;
    if(Circle6Fill>360) {Circle6Prog.sweepAngle = 360;}
    else {Circle6Prog.sweepAngle = Circle6Fill;}
  }
  if(util.getCircleData(1)=="Sec") {
    Circle1Text.text = today.getSeconds();
    Circle1Label.text=util.getLabel(1);
    Circle1Prog.sweepAngle = today.getSeconds()/60*360;
  }
  if(util.getCircleData(2)=="Sec") {
    Circle2Text.text = today.getSeconds();
    Circle2Label.text=util.getLabel(2);
    Circle2Prog.sweepAngle = today.getSeconds()/60*360;
  }
  if(util.getCircleData(3)=="Sec") {
    Circle3Text.text = today.getSeconds();
    Circle3Label.text=util.getLabel(3);
    Circle3Prog.sweepAngle = today.getSeconds()/60*360;
  }
  if(util.getCircleData(4)=="Sec") {
    Circle4Text.text = today.getSeconds();
    Circle4Label.text=util.getLabel(4);
    Circle4Prog.sweepAngle = today.getSeconds()/60*360;
  }
  if(util.getCircleData(5)=="Sec") {
    Circle5Text.text = today.getSeconds();
    Circle5Label.text=util.getLabel(5);
    Circle5Prog.sweepAngle = today.getSeconds()/60*360;
  }
  if(util.getCircleData(6)=="Sec") {
    Circle6Text.text = today.getSeconds();
    Circle6Label.text=util.getLabel(6);
    Circle6Prog.sweepAngle = today.getSeconds()/60*360;
  }
  

}
