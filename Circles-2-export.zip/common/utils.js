import {today,goals} from "user-activity";
import { battery } from "power";
import * as fs from "fs";
import document from "document";


export var timeFormat="24";
var dateFormat="UK";

var Elements = ["steps","calories","elevationGain","activeMinutes","distance","battery","hr","seconds"]
var circle1Element = 0;
var circle2Element = 1;
var circle3Element = 7;
var circle4Element = 6;
var circle5Element = 5;
var circle6Element = 4;

export function zeroPad(i) {
  if (i < 10) {
    i = "0" + i;
  }
  return i;
}

export function getDay(i) {
  let Days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  return Days[i];
}

export function getDate(d,m) {
  if(dateFormat=="UK") {
    return zeroPad(d)+"/"+zeroPad(m);
  }
  else{
    return zeroPad(m)+"/"+zeroPad(d);
  }
}

export function getElementData(index) {
  if(index==0) {return today.adjusted.steps;}
  if(index==1) {return today.adjusted.calories;}
  if(index==2) {if(today.elevationGain){return today.elevationGain;}else{return 0;}}
  if(index==3) {return today.adjusted.activeMinutes;}
  if(index==4) {return today.adjusted.distance;}
  if(index==5) {return battery.chargeLevel;}
  if(index==6) {return "HR";}
  if(index==7) {return "Sec";}
}

export function getElementBoundary(index) {
  if(index==0) {return goals.steps;}
  if(index==1) {return goals.calories;}
  if(index==2) {if(goals.elevationGain){return goals.elevationGain;}else{return 1;}}
  if(index==3) {return goals.activeMinutes;}
  if(index==4) {return goals.distance;}
  if(index==5) {return 100;}
  if(index==6) {return 220;}
  if(index==7) {return 60;}
}

export function getCircleData(circle) {
  if(circle==1) {return getElementData(circle1Element);}
  if(circle==2) {return getElementData(circle2Element);}
  if(circle==3) {return getElementData(circle3Element);}
  if(circle==4) {return getElementData(circle4Element);}
  if(circle==5) {return getElementData(circle5Element);}
  if(circle==6) {return getElementData(circle6Element);}
}

export function getCircleBoundary(circle) {
  if(circle==1) {return getElementBoundary(circle1Element);}
  if(circle==2) {return getElementBoundary(circle2Element);}
  if(circle==3) {return getElementBoundary(circle3Element);}
  if(circle==4) {return getElementBoundary(circle4Element);}
  if(circle==5) {return getElementBoundary(circle5Element);}
  if(circle==6) {return getElementBoundary(circle6Element);}
}

export function setElement(circle,index) {
  if(circle==1) {
    circle1Element=index;
  }
  if(circle==2) {
    circle2Element=index;
  }
  if(circle==3) {
    circle3Element=index;
  }
  if(circle==4) {
    circle4Element=index;
  }
  if(circle==5) {
    circle5Element=index;
  }
  if(circle==6) {
    circle6Element=index;
  }
}

export function getLabel(circle) {
  if(circle==1) {
    if(circle1Element==0){return "STEPS";}
    if(circle1Element==1){return "KCAL";}
    if(circle1Element==2){return "m";}
    if(circle1Element==3){return "MINS";}
    if(circle1Element==4){return "m";}
    if(circle1Element==5){return "%";}
    if(circle1Element==6){return "BPM";}
    if(circle1Element==7){return "s";}
  }
  if(circle==2) {
    if(circle2Element==0){return "STEPS";}
    if(circle2Element==1){return "KCAL";}
    if(circle2Element==2){return "m";}
    if(circle2Element==3){return "MINS";}
    if(circle2Element==4){return "m";}
    if(circle2Element==5){return "%";}
    if(circle2Element==6){return "BPM";}
    if(circle2Element==7){return "s";}
  }
  if(circle==3) {
    if(circle3Element==0){return "STEPS";}
    if(circle3Element==1){return "KCAL";}
    if(circle3Element==2){return "m";}
    if(circle3Element==3){return "MINS";}
    if(circle3Element==4){return "m";}
    if(circle3Element==5){return "%";}
    if(circle3Element==6){return "BPM";}
    if(circle3Element==7){return "s";}
  }
  if(circle==4) {
    if(circle4Element==0){return "STEPS";}
    if(circle4Element==1){return "KCAL";}
    if(circle4Element==2){return "m";}
    if(circle4Element==3){return "MINS";}
    if(circle4Element==4){return "m";}
    if(circle4Element==5){return "%";}
    if(circle4Element==6){return "BPM";}
    if(circle4Element==7){return "s";}
  }
  if(circle==5) {
    if(circle5Element==0){return "STEPS";}
    if(circle5Element==1){return "KCAL";}
    if(circle5Element==2){return "m";}
    if(circle5Element==3){return "MINS";}
    if(circle5Element==4){return "m";}
    if(circle5Element==5){return "%";}
    if(circle5Element==6){return "BPM";}
    if(circle5Element==7){return "s";}
  }
  if(circle==6) {
    if(circle6Element==0){return "STEPS";}
    if(circle6Element==1){return "KCAL";}
    if(circle6Element==2){return "m";}
    if(circle6Element==3){return "MINS";}
    if(circle6Element==4){return "m";}
    if(circle6Element==5){return "%";}
    if(circle6Element==6){return "BPM";}
    if(circle6Element==7){return "s";}
  }
}

export function toggleTimeFormat() {
  if(timeFormat==24) {
    timeFormat=12;
  }
  else{
    timeFormat=24;
  }
}

export function toggleDateFormat() {
  if(dateFormat=="UK") {
    dateFormat="US";
  }
  else{
    dateFormat="UK";
  }
}

export function saveSettings() {
  let Circle1Prog = document.getElementById("Circle1Prog");
  let Circle2Prog = document.getElementById("Circle2Prog");
  let Circle3Prog = document.getElementById("Circle3Prog");
  let Circle4Prog = document.getElementById("Circle4Prog");
  let Circle5Prog = document.getElementById("Circle5Prog");
  let Circle6Prog = document.getElementById("Circle6Prog");
  let data = {
    "circle1Element":circle1Element,
    "circle2Element":circle2Element,
    "circle3Element":circle3Element,
    "circle4Element":circle4Element,
    "circle5Element":circle5Element,
    "circle6Element":circle6Element,
    "circle1Colour":Circle1Prog.style.fill,
    "circle2Colour":Circle2Prog.style.fill,
    "circle3Colour":Circle3Prog.style.fill,
    "circle4Colour":Circle4Prog.style.fill,
    "circle5Colour":Circle5Prog.style.fill,
    "circle6Colour":Circle6Prog.style.fill,
    "timeFormat":timeFormat,
    "dateFormat":dateFormat,
  }
  fs.writeFileSync("settings.txt", data, "json");
}

export function loadSettings() {
  if (fs.existsSync("/private/data/settings.txt")) {
    let Circle1Prog = document.getElementById("Circle1Prog");
    let Circle2Prog = document.getElementById("Circle2Prog");
    let Circle3Prog = document.getElementById("Circle3Prog");
    let Circle4Prog = document.getElementById("Circle4Prog");
    let Circle5Prog = document.getElementById("Circle5Prog");
    let Circle6Prog = document.getElementById("Circle6Prog");
    let data  = fs.readFileSync("settings.txt", "json");
    circle1Element = data.circle1Element;
    circle2Element = data.circle2Element;
    circle3Element = data.circle3Element;
    circle4Element = data.circle4Element;
    circle5Element = data.circle5Element;
    circle6Element = data.circle6Element;
    Circle1Prog.style.fill = data.circle1Colour;
    Circle2Prog.style.fill = data.circle2Colour;
    Circle3Prog.style.fill = data.circle3Colour;
    Circle4Prog.style.fill = data.circle4Colour;
    Circle5Prog.style.fill = data.circle5Colour;
    Circle6Prog.style.fill = data.circle6Colour;
    timeFormat = data.timeFormat;
    dateFormat = data.dateFormat;
  }
}





