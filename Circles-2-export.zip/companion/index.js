import { settingsStorage } from "settings";
import * as messaging from "messaging";
import { me } from "companion";
import * as kpay from './kpay/release/kpay_companion.js';
import * as kpay_common from '../common/kpay/kpay_common.js';
kpay.initialize();
// settingsStorage.setItem("Circle1Element", JSON.stringify({"selected":[0],"values":[{"name":"Steps","value":"0"}]})) ;
// settingsStorage.setItem("Circle2Element", JSON.stringify({"selected":[1],"values":[{"name":"Calories","value":"1"}]})) ;
// settingsStorage.setItem("Circle3Element", JSON.stringify({"selected":[7],"values":[{"name":"Seconds","value":"7"}]})) ;
// settingsStorage.setItem("Circle4Element", JSON.stringify({"selected":[6],"values":[{"name":"Heart Rate","value":"6"}]})) ;
// settingsStorage.setItem("Circle5Element", JSON.stringify({"selected":[5],"values":[{"name":"Battery","value":"5"}]})) ;



// Settings have been changed
settingsStorage.onchange = function(evt) {
  sendValue(evt.key, evt.newValue);
}

// Settings were changed while the companion was not running
if (me.launchReasons.settingsChanged) {
  // sendValue(KEY_COLOR, settingsStorage.getItem(KEY_COLOR));
  // Need to somehow figure out whats changed then send??
}

function sendValue(key, val) {
  if (val) {
    sendSettingData({
      key: key,
      value: JSON.parse(val)
    });
  }
}
function sendSettingData(data) {
  // If we have a MessageSocket, send the data to the device
  if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {
    messaging.peerSocket.send(data);
  } else {
    console.log("No peerSocket connection");
  }
}