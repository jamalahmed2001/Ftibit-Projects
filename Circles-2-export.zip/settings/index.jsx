function mainSettings(props) {
  return (
    <Page>
      <Toggle
        settingsKey="TimeFormat"
        label="12 Hour Format"
      />
      <Toggle
        settingsKey="DateFormat"
        label="US Date Format"
      />
      <Select
        label={"Circle 1 (Top Left)"}
        settingsKey="Circle1Element"
        options={[
          {name:"Steps",value:"0"},
          {name:"Calories",value:"1"},
          {name:"Floors",value:"2"},
          {name:"Active Minutes",value:"3"},
          {name:"Distance",value:"4"},
          {name:"Battery",value:"5"},
          {name:"Heart Rate",value:"6"},
          {name:"Seconds",value:"7"}
        ]}
      />
      <ColorSelect
          settingsKey="Circle1Colour"
          colors={[
            {color: 'grey'},
            {color: 'red'},
            {color: 'crimson'},
            {color: 'orange'},
            {color: 'yellow'},
            {color: 'green'},
            {color: 'darkgreen'},
            {color: 'aquamarine'},
            {color: 'blue'},
            {color: 'darkblue'},
            {color: 'violet'},
            {color: 'magenta'},
            {color: 'darkviolet'}
          ]}
        />
      <Select
        label={"Circle 2 (Middle Left)"}
        settingsKey="Circle2Element"
        options={[
          {name:"Steps"},
          {name:"Calories"},
          {name:"Floors"},
          {name:"Active Minutes"},
          {name:"Distance"},
          {name:"Battery"},
          {name:"Heart Rate"},
          {name:"Seconds"}
        ]}
      />
      <ColorSelect
          settingsKey="Circle2Colour"
          colors={[
            {color: 'grey'},
            {color: 'red'},
            {color: 'crimson'},
            {color: 'orange'},
            {color: 'yellow'},
            {color: 'green'},
            {color: 'darkgreen'},
            {color: 'aquamarine'},
            {color: 'blue'},
            {color: 'darkblue'},
            {color: 'violet'},
            {color: 'magenta'},
            {color: 'darkviolet'}
          ]}
        />
      <Select
        label={"Circle 3 (Bottom Left)"}
        settingsKey="Circle3Element"
        options={[
          {name:"Steps"},
          {name:"Calories"},
          {name:"Floors"},
          {name:"Active Minutes"},
          {name:"Distance"},
          {name:"Battery"},
          {name:"Heart Rate"},
          {name:"Seconds"}
        ]}
      />
      <ColorSelect
          settingsKey="Circle3Colour"
          colors={[
            {color: 'grey'},
            {color: 'red'},
            {color: 'crimson'},
            {color: 'orange'},
            {color: 'yellow'},
            {color: 'green'},
            {color: 'darkgreen'},
            {color: 'aquamarine'},
            {color: 'blue'},
            {color: 'darkblue'},
            {color: 'violet'},
            {color: 'magenta'},
            {color: 'darkviolet'}
          ]}
        />
      <Select
        label={"Circle 4 (Top Right)"}
        settingsKey="Circle4Element"
        options={[
          {name:"Steps"},
          {name:"Calories"},
          {name:"Floors"},
          {name:"Active Minutes"},
          {name:"Distance"},
          {name:"Battery"},
          {name:"Heart Rate"},
          {name:"Seconds"}
        ]}
      />
      <ColorSelect
          settingsKey="Circle4Colour"
          colors={[
            {color: 'grey'},
            {color: 'red'},
            {color: 'crimson'},
            {color: 'orange'},
            {color: 'yellow'},
            {color: 'green'},
            {color: 'darkgreen'},
            {color: 'aquamarine'},
            {color: 'blue'},
            {color: 'darkblue'},
            {color: 'violet'},
            {color: 'magenta'},
            {color: 'darkviolet'}
          ]}
        />
      <Select
        label={"Circle 5 (Middle Right)"}
        settingsKey="Circle5Element"
        options={[
          {name:"Steps"},
          {name:"Calories"},
          {name:"Floors"},
          {name:"Active Minutes"},
          {name:"Distance"},
          {name:"Battery"},
          {name:"Heart Rate"},
          {name:"Seconds"}
        ]}
      />
      <ColorSelect
          settingsKey="Circle5Colour"
          colors={[
            {color: 'grey'},
            {color: 'red'},
            {color: 'crimson'},
            {color: 'orange'},
            {color: 'yellow'},
            {color: 'green'},
            {color: 'darkgreen'},
            {color: 'aquamarine'},
            {color: 'blue'},
            {color: 'darkblue'},
            {color: 'violet'},
            {color: 'magenta'},
            {color: 'darkviolet'}
          ]}
        />
      <Select
        label={"Circle 6 (Bottom Right)"}
        settingsKey="Circle6Element"
        options={[
          {name:"Steps"},
          {name:"Calories"},
          {name:"Floors"},
          {name:"Active Minutes"},
          {name:"Distance"},
          {name:"Battery"},
          {name:"Heart Rate"},
          {name:"Seconds"}
        ]}
      />
      <ColorSelect
          settingsKey="Circle6Colour"
          colors={[
            {color: 'grey'},
            {color: 'red'},
            {color: 'crimson'},
            {color: 'orange'},
            {color: 'yellow'},
            {color: 'green'},
            {color: 'darkgreen'},
            {color: 'aquamarine'},
            {color: 'blue'},
            {color: 'darkblue'},
            {color: 'violet'},
            {color: 'magenta'},
            {color: 'darkviolet'}
          ]}
        />
    </Page>
  );
}

registerSettingsPage(mainSettings);