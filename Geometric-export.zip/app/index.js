import clock from "clock";
import document from "document";
import * as util from "../common/utils";
import { HeartRateSensor } from "heart-rate";
import { display } from "display";
import * as messaging from "messaging";

import * as kpay from './kpay/release/kpay.js';
import * as kpay_common from '../common/kpay/kpay_common.js';
import './kpay/release/kpay_filetransfer.js';
import './kpay/release/kpay_dialogs.js';
import './kpay/release/kpay_time_trial.js';
// import './kpay/release/kpay_msg_validation.js';

kpay.initialize();
util.loadSettings();
clock.granularity = "seconds";

let hourHand = document.getElementById("hours");
let minHand = document.getElementById("mins");
let secHand = document.getElementById("secs");
let tl = document.getElementById("tlElement");
let tr = document.getElementById("trElement");
let bl = document.getElementById("blElement");
let br = document.getElementById("brElement");
let tlImage = document.getElementById("tlImage");
let trImage = document.getElementById("trImage");
let blImage = document.getElementById("blImage");
let brImage = document.getElementById("brImage");
let twelve = document.getElementById("12");
let three = document.getElementById("3");
let six = document.getElementById("6");
let nine = document.getElementById("9");

function hoursToAngle(hours, minutes) {
  let hourAngle = (360 / 12) * hours;
  let minAngle = (360 / 12 / 60) * minutes;
  return hourAngle + minAngle;
}

function minutesToAngle(minutes) {return (360 / 60) * minutes;}
function secondsToAngle(seconds) {return (360 / 60) * seconds;}

function updateClock() {
  let today = new Date();
  let hours = today.getHours() % 12;
  let mins = today.getMinutes();
  let secs = today.getSeconds();

  hourHand.groupTransform.rotate.angle = hoursToAngle(hours, mins);
  minHand.groupTransform.rotate.angle = minutesToAngle(mins);
  secHand.groupTransform.rotate.angle = secondsToAngle(secs);
}

if (HeartRateSensor) {
    const hrm = new HeartRateSensor();
    hrm.addEventListener("reading", () => {});
    display.addEventListener("change", () => {
    display.on ? hrm.start() : hrm.stop();});
    hrm.onreading = function() {
      if(util.getElementData("tl")=="HR") {
        tl.text = `${hrm.heartRate}`;
        tlImage.href="hr.png";
      }
      if(util.getElementData("tr")=="HR") {
        tr.text = `${hrm.heartRate}`;
        trImage.href="hr.png";
      }
      if(util.getElementData("bl")=="HR") {
        bl.text = `${hrm.heartRate}`;
        blImage.href="hr.png";
      }
      if(util.getElementData("br")=="HR") {
        br.text = `${hrm.heartRate}`;
        brImage.href="hr.png";
      }
    }
    hrm.start();
}
 
clock.ontick = (evt) => {
  updateClock();
  let today = evt.date;
  messaging.peerSocket.onmessage = function(evt) {
    if(evt.data.key=="TLElement") {
      util.setElement("tl",evt.data.value.selected);
    }
    if(evt.data.key=="TRElement") {
      util.setElement("tr",evt.data.value.selected);
    }
    if(evt.data.key=="BLElement") {
      util.setElement("bl",evt.data.value.selected);
    }
    if(evt.data.key=="BRElement") {
      util.setElement("br",evt.data.value.selected);
    }
    if(evt.data.key=="DateFormat") {
      util.toggleDateFormat();
    }
    if(evt.data.key=="showNumbers") {
      util.toggleNumbers();
    }
    if(evt.data.key=="showStats") {
      util.toggleStats();
    }
    util.saveSettings();
  }
  
  if(util.getElementData("tl")!="HR"&&util.getElementData("tl")!="Date"){
    tl.text = util.getElementData("tl");
    tlImage.href = util.getLogo("tl");
  }
  if(util.getElementData("tr")!="HR"&&util.getElementData("tr")!="Date"){
    tr.text = util.getElementData("tr");
    trImage.href = util.getLogo("tr");
  }
  if(util.getElementData("bl")!="HR"&&util.getElementData("bl")!="Date"){
    bl.text = util.getElementData("bl");
    blImage.href = util.getLogo("bl");
  }
  if(util.getElementData("br")!="HR"&&util.getElementData("br")!="Date"){
    br.text = util.getElementData("br");
    brImage.href = util.getLogo("br");
  }
  
  if(util.getElementData("tl")=="Date") {
    tl.text = util.getDate(evt.date.getDate(),evt.date.getMonth()+1);
  }

  if(util.Numbers){
    twelve.style.display="inline";
    three.style.display="inline";
    six.style.display="inline";
    nine.style.display="inline";
  }
  else{
    twelve.style.display="none";
    three.style.display="none";
    six.style.display="none";
    nine.style.display="none";
  }
  
  if(util.Stats) {
    tl.style.display="inline";
    tr.style.display="inline";
    bl.style.display="inline";
    br.style.display="inline";
    tlImage.style.display="inline";
    trImage.style.display="inline";
    blImage.style.display="inline";
    brImage.style.display="inline";    
  }
  else{
    tl.style.display="none";
    tr.style.display="none";
    bl.style.display="none";
    br.style.display="none";
    tlImage.style.display="none";
    trImage.style.display="none";
    blImage.style.display="none";
    brImage.style.display="none";  
  }
  
  
}

