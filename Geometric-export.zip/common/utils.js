import {today,goals} from "user-activity";
import { battery } from "power";
import * as fs from "fs";
import document from "document";

var dateFormat="UK";
var Elements = ["steps","calories","elevationGain","activeMinutes","distance","battery","hr","Date"]
var tl = 0;
var tr = 1;
var bl = 5;
var br = 6;
export var Numbers = 0;
export var Stats = 0;

export function zeroPad(i) {
  if (i < 10) {
    i = "0" + i;
  }
  return i;
}

export function getDay(i) {
  let Days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
  return Days[i];
}

export function getDate(d,m) {
  if(dateFormat=="UK") {
    return zeroPad(d)+"/"+zeroPad(m);
  }
  else{
    return zeroPad(m)+"/"+zeroPad(d);
  }
}

export function toggleDateFormat() {
  if(dateFormat=="UK") {
    dateFormat="US";
  }
  else{
    dateFormat="UK";
  }
}

export function toggleNumbers() {
  if(Numbers) {
    Numbers=0;
  }
  else{
    Numbers=1;
  }
}

export function toggleStats() {
  if(Stats) {
    Stats=0;
  }
  else{
    Stats=1;
  }
}
export function saveSettings() {
  let data = {
    "dateFormat":dateFormat,
    "tl":tl,
    "tr":tr,
    "bl":bl,
    "br":br,
    "Numbers":Numbers,
    "showStats":Stats,
  }
  fs.writeFileSync("settings.txt", data, "json");
}

export function loadSettings() {
  if (fs.existsSync("/private/data/settings.txt")) {
    let data  = fs.readFileSync("settings.txt", "json");
    dateFormat = data.dateFormat;
    tl = data.tl;
    tr = data.tr;
    bl = data.bl;
    br = data.br;
    Numbers=data.Numbers;
    Stats = data.showStats;
  }
}

function getData(index) {
  if(index==0) {return today.adjusted.steps;}
  if(index==1) {return today.adjusted.calories;}
  if(index==2) {if(today.elevationGain){return today.elevationGain;}else{return 0;}}
  if(index==3) {return today.adjusted.activeMinutes;}
  if(index==4) {return today.adjusted.distance;}
  if(index==5) {return battery.chargeLevel;}
  if(index==6) {return "HR";}
  if(index==7) {return "Date";}
}

export function getElementData(elem) {
  if(elem=="tl"){return(getData(tl));}
  if(elem=="tr"){return(getData(tr));}
  if(elem=="bl"){return(getData(bl));}
  if(elem=="br"){return(getData(br));}
}

export function getLogo(elem) {
  if(elem=="tl"){
    if(tl==0){return "steps.png";}
    if(tl==1){return "calories.png";}
    if(tl==2){return "floors.png";}
    if(tl==3){return "batt.png";}
    if(tl==4){return "distance.png";}
    if(tl==5){return "batt.png";}
    if(tl==6){return "hr.png";}
    // if(tl==7){return getDay();}
  }
  if(elem=="tr"){
    if(tr==0){return "steps.png";}
    if(tr==1){return "calories.png";}
    if(tr==2){return "floors.png";}
    if(tr==3){return "batt.png";}
    if(tr==4){return "distance.png";}
    if(tr==5){return "batt.png";}
    if(tr==6){return "hr.png";}
    // if(tr==7){return getDay();}
  }
  if(elem=="bl"){
    if(bl==0){return "steps.png";}
    if(bl==1){return "calories.png";}
    if(bl==2){return "floors.png";}
    if(bl==3){return "batt.png";}
    if(bl==4){return "distance.png";}
    if(bl==5){return "batt.png";}
    if(bl==6){return "hr.png";}
    // if(bl==7){return getDay();}
  }
  if(elem=="br"){
    if(br==0){return "steps.png";}
    if(br==1){return "calories.png";}
    if(br==2){return "floors.png";}
    if(br==3){return "batt.png";}
    if(br==4){return "distance.png";}
    if(br==5){return "batt.png";}
    if(br==6){return "hr.png";}
    // if(br==7){return getDay();}
  }
}

export function setElement(elem,index) {
  if(elem=="tl"){
    tl=index;
  }
  if(elem=="tr"){
    tr=index;
  }
  if(elem=="bl"){
    bl=index;
  }
  if(elem=="br"){
    br=index;
  }
}

