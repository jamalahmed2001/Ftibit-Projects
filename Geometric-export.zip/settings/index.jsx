function mainSettings(props) {
  return (
    <Page>
      <Toggle
        settingsKey="DateFormat"
        label="US Date Format"
      />
      <Toggle
        settingsKey="showNumbers"
        label="Show numbers on clock"
      />
      <Toggle
        settingsKey="showStats"
        label="Show Stats"
      />
      <Select
        label={"Top Left"}
        settingsKey="TLElement"
        options={[
          {name:"Steps",value:"0"},
          {name:"Calories",value:"1"},
          {name:"Floors",value:"2"},
          {name:"Active Minutes",value:"3"},
          {name:"Distance",value:"4"},
          {name:"Battery",value:"5"},
          {name:"Heart Rate",value:"6"},
          {name:"Date",value:"7"}
        ]}
      />
      <Select
        label={"Top Right"}
        settingsKey="TRElement"
        options={[
          {name:"Steps"},
          {name:"Calories"},
          {name:"Floors"},
          {name:"Active Minutes"},
          {name:"Distance"},
          {name:"Battery"},
          {name:"Heart Rate"},
          {name:"Date"}
        ]}
      />
      <Select
        label={"Bottom Left"}
        settingsKey="BLElement"
        options={[
          {name:"Steps"},
          {name:"Calories"},
          {name:"Floors"},
          {name:"Active Minutes"},
          {name:"Distance"},
          {name:"Battery"},
          {name:"Heart Rate"},
          {name:"Date"}
        ]}
      />
      <Select
        label={"Bottom Right"}
        settingsKey="BRElement"
        options={[
          {name:"Steps"},
          {name:"Calories"},
          {name:"Floors"},
          {name:"Active Minutes"},
          {name:"Distance"},
          {name:"Battery"},
          {name:"Heart Rate"},
          {name:"Date"}
        ]}
      />
    </Page>
  );
}

registerSettingsPage(mainSettings);