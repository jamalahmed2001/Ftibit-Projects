import document from "document";
import * as messaging from "messaging";

let container = document.getElementById("container");
// Get the selected index
let currentIndex = container.value;
// Set the selected index
container.value = 0; // jump to first slide

messaging.peerSocket.addEventListener("open", (evt) => {
  console.log("Connection Established");
});

messaging.peerSocket.addEventListener("error", (err) => {
  console.error(`Connection error: ${err.code} - ${err.message}`);
});

let powerButton = document.getElementById("PowerButton");
powerButton.onactivate = function(evt) {
  console.log("clicked");
  if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {
    messaging.peerSocket.send("togglePower");
  }
}

let modeList = document.getElementById("ModeList");
let items = modeList.getElementsByClassName("tile-list-item");

items.forEach((element, index) => {
  let touch = element.getElementById("touch-me");
  touch.onclick = (evt) => {
    console.log(`touched: ${index+1}`);
    if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {
      messaging.peerSocket.send(["Mode",`${index+1}`]);
    }
  }
});
  
let BrightnessTumbler = document.getElementById("tumbler");
BrightnessTumbler.addEventListener("select",(evt) => {
  let Index = parseInt(BrightnessTumbler.value);
  let Item = BrightnessTumbler.getElementById(`item${Index}`);
  let Val = Item.getElementById("content").text;
  if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {
      messaging.peerSocket.send(["Brightness",Val]);
    }
});  



