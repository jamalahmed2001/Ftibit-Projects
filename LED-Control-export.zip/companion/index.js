import * as messaging from "messaging";

var base = "http://192.168.0.66:8080/i6r8rCurbyw3XRz02YWKfFzeQfFbXg93";

async function sendCommand(request) {
  console.error(request);
  var URL = base+request;
  const response = await fetch(URL);
  const json = await response.json();
  return json
}

function togglePowerV0() {
  sendCommand("/get/V0").then(function(state) {
    console.log(state);
    if (state==0) {
      sendCommand("/update/V0?value=1").then(data=>console.log(data)).catch(e=>console.log(e));
    }
    else if(state==1) {
      sendCommand("/update/V0?value=0").then(data=>console.log(data)).catch(e=>console.log(e));
    }
  }).catch(e=>console.log(e));
}



messaging.peerSocket.addEventListener("message", (evt) => {
  if (evt.data && evt.data === "togglePower") {
    togglePowerV0();
  }
  else if(evt.data && Array.isArray(evt.data)) {
    console.log(evt.data);
    if(evt.data[0]=="Mode") {
      sendCommand("/update/V3?value="+evt.data[1]).then(data=>console.log(data)).catch(e=>console.log(e));
    }
    else if(evt.data[0]=="Brightness") {
      sendCommand("/update/V1?value="+evt.data[1]).then(data=>console.log(data)).catch(e=>console.log(e));
    }
  }
});

messaging.peerSocket.addEventListener("error", (err) => {
  console.error(`Connection error: ${err.code} - ${err.message}`);
});