import { me as appbit } from "appbit";
import {today} from "user-activity";
import { HeartRateSensor } from "heart-rate";
import { display } from "display";
import clock from "clock";
import document from "document";
import { user } from "user-profile";
import * as stopwatch from "../common/stopwatch";
import * as util from "../common/util";
import exercise from "exercise";
import { vibration } from "haptics";

util.load();

let Time = document.getElementById("Time");
let BPM = document.getElementById("BPM");
let Timer = document.getElementById("Timer");
let Laps = document.getElementById("Laps");
let play = document.getElementById("btn-tr");
let set = document.getElementById("btn-tl");
let reset = document.getElementById("btn-br");

let File1 = document.getElementById("File1");
let File2 = document.getElementById("File2");
let File3 = document.getElementById("File3");
let File4 = document.getElementById("File4");

let container = document.getElementById("container");
let Settings = document.getElementById("SettingsPage");
let PoolLengthButton = document.getElementById("PoolLengthButton");
let DateFormatButton = document.getElementById("DateFormatButton");
let FileManagementButton = document.getElementById("FileManagementButton");

let PoolLengthSettings = document.getElementById("PoolLengthSettings");
let tumbler = document.getElementById("PoolTumbler");


var lapTimes = [];
let running=0;
var fileName;

if (HeartRateSensor) {
    const hrm = new HeartRateSensor();
    hrm.addEventListener("reading", () => {});
    display.addEventListener("change", () => {
    display.on ? hrm.start() : hrm.stop();});
    hrm.onreading = function() {BPM.text = `${hrm.heartRate}`; }
    hrm.start();
}

play.onactivate = function(evt) {
  Laps.text = 0;
  lapTimes = []
  stopwatch.resetTimer();
  Timer.text="00:00:00";
  stopwatch.startTimer();
  // exercise.start("swim",{ poolLength:util.PoolLength});
  running=1;
}

reset.onactivate = function(evt) {
  lapTimes = []
  stopwatch.resetTimer();
  Laps.text = 0;
  Timer.text="00:00:00";
  running=0;
}

File1.onactivate = function(evt) {util.readFile(0);container.value=2;}
File2.onactivate = function(evt) {util.readFile(1);container.value=2;}
File3.onactivate = function(evt) {util.readFile(2);container.value=2;}
File4.onactivate = function(evt) {util.readFile(3);container.value=2;}

//Main settings open
set.onactivate = function(evt) {
  PoolLengthButton.text = "Pool Length: " +util.PoolLength+"m";
  DateFormatButton.text = "Date Format: " + util.dateFormat;
  Settings.style.display="inline";
  set.style.display="none";
  play.style.display="none";
  reset.style.display="none";
}
//Pool length Settings open
PoolLengthButton.onactivate = function(evt) {
  Settings.style.display="none";
  PoolLengthSettings.style.display="inline";
} 

DateFormatButton.onactivate = function(evt) {
  util.toggleDateFormat();
  DateFormatButton.text = "Date Format: " + util.dateFormat;
}

FileManagementButton.onactivate = function(evt) {
  util.transferFiles();
}
  
clock.granularity = "seconds";
clock.ontick = function(evt) {
  if(util.dateFormat=="UK") {fileName = evt.date.getHours()+"."+evt.date.getMinutes() +"@"+ evt.date.getDate()+"-"+(evt.date.getMonth()+1);}
  else {fileName = (evt.date.getMonth()+1)+"-"+evt.date.getDate()+"@"+evt.date.getHours()+"-"+evt.date.getMinutes();}
  Time.text = ("0" + evt.date.getHours()).slice(-2) + ":" + ("0" + evt.date.getMinutes()).slice(-2);
  if(!stopwatch.getPaused()&&stopwatch.getRunning()!=0) {Timer.text = stopwatch.getShowTime().slice(0,-2);}

  document.onkeypress = function(e) {
    e.preventDefault();
    //Close main settings
    if(Settings.style.display=="inline") {
      Settings.style.display="none";
      set.style.display="inline";
      play.style.display="inline";
      reset.style.display="inline";
    }
    //Close pool length settings
    else if(PoolLengthSettings.style.display=="inline") {
      let selectedIndex = tumbler.value;
      let selectedItem = tumbler.getElementById("item" + selectedIndex);
      let selectedValue = selectedItem.getElementById("content").text;
      util.setPoolLength(selectedValue);
      util.saveSettings();
      Settings.style.display="inline";
      PoolLengthButton.text = "Pool Length: " +util.PoolLength+"m";
      PoolLengthSettings.style.display="none";
    }
    
    else if(e.key=="back"&&running==1) {
      lapTimes.push(stopwatch.getShowTime());
      // exercise.splitLap();
      Laps.text=parseInt(Laps.text)+1;
      vibration.start("ping");
      vibration.stop();
      document.onkeypress = function(evt) {
        evt.preventDefault();
        if(evt.key=="back") {
          // exercise.stop();
          running=0;
          stopwatch.pauseTimer();
          util.saveWorkout(lapTimes,fileName);
        }
      }
    }
    else if (e.key=="back"&&running==0){
      appbit.exit();
    }
  }
  
}