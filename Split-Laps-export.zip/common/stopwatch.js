import document from "document";

var timerDisplay = document.getElementById("Timer");
var startTime;
var updatedTime;
var difference;
var savedTime;
var paused = 0;
var running = 0;
timerDisplay.text = "00:00:00";

export function getRunning() {
  return running;
}
export function getPaused() {
  return paused;
}

export function startTimer(){
  if(!running){
    startTime = new Date().getTime();
    paused = 0;
    running = 1;
  }
}

export function pauseTimer(){
  if (!difference){
    // if timer never started, don't allow pause button to do anything
  } else if (!paused) {
    savedTime = difference;
    paused = 1;
    running = 0;

  } 
  else {
// if the timer was already paused, when they click pause again, start the timer again
    startTimer();
  }
}

export function resetTimer(){
  timerDisplay.text = "00:00:00";
  savedTime = 0;
  difference = 0;
  paused = 0;
  running = 0;
}

export function getShowTime(){
  updatedTime = new Date().getTime();
  if (savedTime){
    difference = (updatedTime - startTime) + savedTime;
  } else {
    difference =  updatedTime - startTime;
  }
  // var days = Math.floor(difference / (1000 * 60 * 60 * 24));
  var hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((difference % (1000 * 60)) / 1000);
  var milliseconds = Math.floor((difference % (1000 * 60)) / 100);
hours = (hours < 10) ? "0" + hours : hours;
  minutes = (minutes < 10) ? "0" + minutes : minutes;
  seconds = (seconds < 10) ? "0" + seconds : seconds;
  milliseconds = (milliseconds < 100) ? (milliseconds < 10) ? "00" + milliseconds : "0" + milliseconds : milliseconds;
  return hours + ':' + minutes + ':' + seconds + ':' + milliseconds.toString().slice(-1);
}