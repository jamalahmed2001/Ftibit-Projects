import * as fs from "fs";
import { listDirSync } from "fs";
import document from "document";
import { outbox } from "file-transfer";

var Files=[];
export var dateFormat="UK";
export var PoolLength = 25;

export function setPoolLength(length) {PoolLength = length;}
export function toggleDateFormat() {
  if(dateFormat=="UK"){dateFormat="US";}
  else{dateFormat="UK";}
}

export function load() {
  loadSettings();
  const listDir = listDirSync("/private/data");
  var dirIter;
  while((dirIter = listDir.next()) && !dirIter.done) {
    Files.push(dirIter.value);
  }
  Files.shift();
  if(Files.length>0) {
    let Timer = document.getElementById("Timer");
    let Laps = document.getElementById("Laps");
    let lapCol = document.getElementById("lapColumn");
    let timeCol = document.getElementById("timeColumn");
    
    let previousData = fs.readFileSync(Files[Files.length-1], "ascii");
    let lapTimes = previousData.split(",");
    
    let lapString = []
    for(var i=1;i<=lapTimes.length;i++) {
      lapString.push(i);
    }
  
    Timer.text = lapTimes[lapTimes.length-1].slice(0,-2);
    Laps.text = lapTimes.length;
    lapCol.text = lapString.join("\n");
    timeCol.text = lapTimes.join("\n");
    

  }

  // fs.unlinkSync(Files[0]);
  // fs.unlinkSync(Files[1]);
  // fs.unlinkSync(Files[2]);
  // fs.unlinkSync(Files[3]);
  updateFiles();
}

export function updateFiles() {
  let File1 = document.getElementById("File1");
  let File2 = document.getElementById("File2");
  let File3 = document.getElementById("File3");
  let File4 = document.getElementById("File4");
  File1.text = Files[0];
  File2.text = Files[1];
  File3.text = Files[2];
  File4.text = Files[3]; 
  // console.log(Files);
}

export function readFile(index) {
  if (fs.existsSync("/private/data/"+Files[index])) {
    let rawData = fs.readFileSync(Files[index], "ascii");
    let lapTimes = rawData.split(",");
    let lapString = []
    for(var i=1;i<=lapTimes.length;i++) {
        lapString.push(i);
    }
    let lapCol = document.getElementById("lapColumn");
    let timeCol = document.getElementById("timeColumn");
    lapCol.text = lapString.join("\n");
    timeCol.text = lapTimes.join("\n");
  }
}

export function saveWorkout(lapTimes,FileName) {
  if(Files.length==4) {
    fs.unlinkSync(Files[0]);
    Files.shift();
  }
  fs.writeFileSync(FileName, lapTimes.join(), "ascii");
  Files.push(FileName);
  updateFiles();
  readFile(Files.length-1);
}


export function saveSettings() {
  let data = {
    "dateFormat": dateFormat,
    "poolLength":PoolLength,
  }
  fs.writeFileSync("0settings.txt", data, "json");
}

function loadSettings() {
  if (fs.existsSync("/private/data/0settings.txt")) {
    let data  = fs.readFileSync("0settings.txt", "json");
    dateFormat = data.dateFormat;
    PoolLength = data.poolLength;
  }
}

export function transferFiles() {
  outbox
  .enqueueFile("/private/data/"+Files[0])
  .then((ft) => {
    console.log(`Transfer of ${ft.name} successfully queued.`);
  })
  .catch((error) => {
    console.log(`Failed to schedule transfer: ${error}`);
  })
}