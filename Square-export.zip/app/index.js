import { me as appbit } from "appbit";
import {today,goals} from "user-activity";
import { HeartRateSensor } from "heart-rate";
import { display } from "display";
import clock from "clock";
import * as messaging from "messaging";
import document from "document";
import { battery } from "power";
import * as util from "../common/utils";
import { user } from "user-profile";
import * as constants from "../common/constants";

constants.loadSettings();

let Time = document.getElementById("Time");
let AMPM = document.getElementById("AMPM");
let Date = document.getElementById("Date");

let Steps = document.getElementById("Steps");
let StepsBar = document.getElementById("StepsBar");

let Cal = document.getElementById("Cal");
let CalBar = document.getElementById("CalBar");

let Battery = document.getElementById("Battery");
let BatteryBar = document.getElementById("BatteryBar");

let BPM = document.getElementById("BPM");
let BPMBar = document.getElementById("BPMBar");

let Active = document.getElementById("Active");

if (HeartRateSensor) {
    const hrm = new HeartRateSensor();
    hrm.addEventListener("reading", () => {});
    display.addEventListener("change", () => {
    display.on ? hrm.start() : hrm.stop();});
    hrm.onreading = function() {
        BPM.text = `${hrm.heartRate}`; 
    }
    hrm.start();
}
  
clock.granularity = "seconds";
clock.ontick = function(evt) {
  
    messaging.peerSocket.onmessage = function(evt) {
        if(evt.data.value && evt.data.key=="TimeFormat") {
            constants.setTimeFormat(24);
        }
        else if(evt.data.key=="TimeFormat") {
            constants.setTimeFormat(12);
        }
    
        if(evt.data.value && evt.data.key=="DateFormat") {
            constants.setDateFormat("US");
        }
        else if(evt.data.key=="DateFormat") {
            constants.setDateFormat("UK");
        }
      constants.saveSettings();
    }
  
    // if(constants.getTimeFormat()==12) {
    //     if(("0" + evt.date.getHours()).slice(-2)>=12) {
    //         if(("0" + evt.date.getHours()).slice(-2)==12) {
    //             Time.text = ("0" + evt.date.getHours()).slice(-2) + ":" + ("0" +evt.date.getMinutes()).slice(-2);
    //         }
    //         else {
    //             Time.text = ("0" + evt.date.getHours()).slice(-2)-12 + ":" + ("0" +evt.date.getMinutes()).slice(-2);
    //         }
    //         AMPM.text = "PM";
    //     }
    //     else{
    //         Time.text = ("0" + evt.date.getHours()).slice(-2)%12 + ":" + ("0" +evt.date.getMinutes()).slice(-2);
    //         AMPM.text = "AM";
    //     }
    //     AMPM.style.display = "inline";
    // }
    // else{
    //     Time.text = ("0" + evt.date.getHours()).slice(-2) + ":" + ("0" + evt.date.getMinutes()).slice(-2);
    //     AMPM.style.display = "none";
    // }
      let Today = evt.date;
      let hours = Today.getHours();
      var h;
      var m;
      if (constants.getTimeFormat() == 12) {
        h = hours % 12 || 12;
        AMPM.style.display = "inline";
        if(hours>=12) {
          AMPM.text = "PM";
        }
        else{
          AMPM.text = "AM";
        }
      } 
      else {
        h = util.zeroPad(hours);
        AMPM.style.display = "none";
      }
      m = util.zeroPad(Today.getMinutes());
      Time.text = h + ":" + m;  
  
    var Days = new Array();
    Days[0] = "SUN";Days[1] = "MON";Days[2] = "TUE";Days[3] = "WED";Days[4] = "THU";Days[5] = "FRI";Days[6] = "SAT";
    if(constants.getDateFormat()=="UK") {
        Date.text = Days[evt.date.getDay()]+ " " + evt.date.getDate()+"/"+(evt.date.getMonth()+1);
    }
    else { 
        Date.text = Days[evt.date.getDay()]+ " " + (evt.date.getMonth()+1)+"/" + evt.date.getDate();
    }

    Active.text = today.adjusted.activeMinutes+" MINS";
  
    Steps.text = today.adjusted.steps || 0;
    let StepPercentage = today.adjusted.steps/goals.steps;
    if (StepPercentage<1) {StepsBar.x2 = 107*StepPercentage;}
    else {StepsBar.x2=107;}
  
    Cal.text = today.adjusted.calories || 0;
    let CalPercentage = today.adjusted.calories/goals.calories;
    if(CalPercentage<1) {CalBar.x2 = 193+(300-193)*CalPercentage;}
    else {CalBar.x2=300;}
  
    Battery.text = battery.chargeLevel+"%";
    BatteryBar.x2 = (battery.chargeLevel/100)*107;
  
    if(BPM.text!="--") {BPMBar.x2= 193+(BPM.text/200)*(300-193);}
  
}
