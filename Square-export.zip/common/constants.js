import * as fs from "fs";

var TimeFormat = 12;
var DateFormat = "UK";

export function setTimeFormat(f) {
  TimeFormat = f;
}

export function getTimeFormat(f) {
  return TimeFormat;
}

export function setDateFormat(f) {
  DateFormat = f;
}

export function getDateFormat(f) {
  return DateFormat;
}

export function saveSettings() {
  let data = {
    "timeFormat" : TimeFormat,
    "dateFormat" : DateFormat,
  }
  fs.writeFileSync("settings.txt", data, "json");
}

export function loadSettings() {
  if (fs.existsSync("/private/data/settings.txt")) {
    let data  = fs.readFileSync("settings.txt", "json");
    TimeFormat = data.timeFormat;
    DateFormat = data.dateFormat;
  }
  
}