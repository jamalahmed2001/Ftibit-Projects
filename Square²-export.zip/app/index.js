import { me as appbit } from "appbit";
import {today,goals} from "user-activity";
import { HeartRateSensor } from "heart-rate";
import { display } from "display";
import clock from "clock";
import * as messaging from "messaging";
import document from "document";
import { battery } from "power";
import * as util from "../common/utils";
import { user } from "user-profile";
import * as constants from "../common/constants";

import * as kpay from './kpay/release/kpay.js';
import * as kpay_common from '../common/kpay/kpay_common.js';
import './kpay/release/kpay_time_trial.js';
import './kpay/release/kpay_filetransfer.js';
import './kpay/release/kpay_dialogs.js';

kpay.initialize();
constants.loadSettings();

let Time = document.getElementById("Time");
let AMPM = document.getElementById("AMPM");
let Date = document.getElementById("Date");
let Steps = document.getElementById("Steps");
let StepsBar = document.getElementById("StepsBar");
let Cal = document.getElementById("Cal");
let CalBar = document.getElementById("CalBar");
let Battery = document.getElementById("Battery");
let BatteryBar = document.getElementById("BatteryBar");
let BPM = document.getElementById("BPM");
let BPMBar = document.getElementById("BPMBar");
let Active = document.getElementById("Active");

let bar1 = document.getElementById("15sec");
let bar2 = document.getElementById("30sec");
let bar3 = document.getElementById("45sec");
let bar4 = document.getElementById("60sec");

if (HeartRateSensor) {
  const hrm = new HeartRateSensor();
    hrm.addEventListener("reading", () => {
  });
  display.addEventListener("change", () => {
    display.on ? hrm.start() : hrm.stop();
  });
  hrm.onreading = function() {
    BPM.text = `${hrm.heartRate}`;
  }
  hrm.start();
}
  
clock.granularity = "seconds";
clock.ontick = function(evt) {
  
  if(evt.date.getSeconds()<15) {
    bar1.x2+=20;
  }
  else if (evt.date.getSeconds()<30) {
    bar1.x2=300;
    bar2.y2+=20;
  }
  else if(evt.date.getSeconds()<45) {
    bar1.x2=300;
    bar2.y2=300;
    bar3.x2-=20;
  }
  else if(evt.date.getSeconds()<59) {
    bar1.x2=300;
    bar2.y2=300;
    bar3.x2=0;
    bar4.y2-=21;
  }
  if(evt.date.getSeconds()==59) {
    bar1.x2 = 0;
    bar2.y2 = 0;
    bar3.x2 = 300;
    bar4.y2 = 300;
  }
  
    messaging.peerSocket.onmessage = function(evt) {
        if(evt.data.value && evt.data.key=="TimeFormat") {
            constants.setTimeFormat(24);
        }
        else if(evt.data.key=="TimeFormat") {
            constants.setTimeFormat(12);
        }
    
        if(evt.data.value && evt.data.key=="DateFormat") {
            constants.setDateFormat("US");
        }
        else if(evt.data.key=="DateFormat") {
            constants.setDateFormat("UK");
        }
      constants.saveSettings();
    }
  
    let Today = evt.date;
    let hours = Today.getHours();
    var h;
    var m;
    if (constants.getTimeFormat() == 12) {
      h = hours % 12 || 12;
      AMPM.style.display = "inline";
      if(hours>=12) {
        AMPM.text = "PM";
      }
      else{
        AMPM.text = "AM";
      }
    } 
    else {
      h = util.zeroPad(hours);
      AMPM.style.display = "none";
    }
    m = util.zeroPad(Today.getMinutes());
    Time.text = h + ":" + m;  
  
    var Days = new Array();
    Days[0] = "SUN";Days[1] = "MON";Days[2] = "TUE";Days[3] = "WED";Days[4] = "THU";Days[5] = "FRI";Days[6] = "SAT";
    if(constants.getDateFormat()=="UK") {
        Date.text = Days[evt.date.getDay()]+ " " + evt.date.getDate()+"/"+(evt.date.getMonth()+1);
    }
    else { 
        Date.text = Days[evt.date.getDay()]+ " " + (evt.date.getMonth()+1)+"/" + evt.date.getDate();
    }
  
  Active.text = today.adjusted.activeMinutes+" MINS";
  Steps.text = today.adjusted.steps || 0;
  let StepPercentage = today.adjusted.steps/goals.steps;
  if(StepPercentage<1) {
    StepsBar.x2 = 24+122*StepPercentage;
    StepsBar.y2 = 146-+122*StepPercentage;
  }
  else {StepsBar.x2=146;StepsBar.y2=24;}
  
  Cal.text = today.adjusted.calories || 0;
  let CalPercentage = today.adjusted.calories/goals.calories;
  if(CalPercentage<1) {
    CalBar.x2 = 154+122*CalPercentage;
    CalBar.y2 = 24+122*CalPercentage;
  }
  else {CalBar.x2=276;CalBar.y2=146;}
  
  Battery.text = battery.chargeLevel+"%";
  BatteryBar.x2 = 146-(battery.chargeLevel/100)*122;
  BatteryBar.y2 = 276-(battery.chargeLevel/100)*122;
  
  if(BPM.text!="--") {BPMBar.x2= 276-(BPM.text/200)*122;BPMBar.y2 = 154+(BPM.text/200)*122;}
  
}
