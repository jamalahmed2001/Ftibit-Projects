import { settingsStorage } from "settings";
import * as messaging from "messaging";
import { me } from "companion";

let format="TimeFormat";
let DateFormat = settingsStorage.getItem("DateFormat");


messaging.peerSocket.onopen = () => {
  sendValue(format, settingsStorage.getItem(format));
};

settingsStorage.onchange = function(evt) {
  sendValue(evt.key, evt.newValue);
}

if (me.launchReasons.settingsChanged) {
  sendValue(format, settingsStorage.getItem(format));
}

function sendValue(key, val) {
  if (val) {
    sendSettingData({
      key: key,
      value: JSON.parse(val)
    });
  }
}

function sendSettingData(data) {
  // If we have a MessageSocket, send the data to the device
  if (messaging.peerSocket.readyState === messaging.peerSocket.OPEN) {
    messaging.peerSocket.send(data);
  } else {
    console.log("No peerSocket connection");
  }
}