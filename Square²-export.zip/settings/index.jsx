function TimeFormat(props) {
  return (
    <Page>
      <Section
        title={<Text bold align="center">Time Settings</Text>}>
        <Toggle
          settingsKey="TimeFormat"
          label="24 Hour Format"
        />
      </Section>
      <Section
        title={<Text bold align="center">Date Settings</Text>}>
        <Toggle
          settingsKey="DateFormat"
          label="US Format"
        />
      </Section>
    </Page>
  );
}

registerSettingsPage(TimeFormat);